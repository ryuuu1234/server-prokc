Let's review some of the options in the `config/jwt.php` file that we published earlier.
I won't go through all of the options here since [the file itself](https://github.com/tymondesigns/jwt-auth/blob/1.0.0-beta.2/config/config.php) is pretty well documented.

First up is:

```
'secret' => env('JWT_SECRET'),
```

Coming soon...
