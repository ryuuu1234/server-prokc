- [The Anatomy of a JSON Web Token](https://scotch.io/tutorials/the-anatomy-of-a-json-web-token)
- [jwt.io](https://jwt.io/)

Over the last couple of years, the community has provided some great tutorials and packages that
have helped people get up and running with jwt-auth. So it's only right that I post some of them here.

Coming soon...
